from setuptools import setup
setup(name="packageMaulik",
version ="0.1",
description="This is code with Maulik package",
Long_description="This is very Long description",
author="Maulik",
package=['packageMaulik'],
install_requires=[])
